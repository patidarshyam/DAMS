package com.yash.damsapp.dao;

import java.util.List;

import com.yash.damsapp.domain.Appointment;
/**
 * This interface perform operation related with Appointment.
 * @author shyam.patidar
 *
 */
public interface AppointmentDAO {
	/**
	 * This method will save the Appointment Object into database.Return 1 if data inserted into DB.
	 *
	 * @param appointment
	 * @return int
	 *
	 */
	public int insert(Appointment appointment);
	
	public List<Appointment> select(Integer userId);

	public int updateAppointmentStatus(int id);

	public int cancel(int id, String message);

}
