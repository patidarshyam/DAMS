package com.yash.damsapp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;

/**
 * This controller will perform user related controlling.
 * 
 * @author shyam.patidar
 *
 */
@Controller
@RequestMapping("/admin")
@SessionAttributes("userinsession")
public class AdminController {
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/listRegisteredUser.htm", method = RequestMethod.GET)
	public String showRegisteredUserPage(HttpSession session,Model model) {
		User user = (User) session.getAttribute("userinsession");
		if (user.getLoginname() == null)
			return "userLogin";
		else {
			List<User> listRegisteredUser = userService.listRegisteredUser();
			model.addAttribute("listRegisteredUser", listRegisteredUser);
			return "listRegisteredUser";
		}
	}
	@RequestMapping(value = "/changeUserStatus.htm", method = RequestMethod.GET)
	public String changeUserStatus(@RequestParam("id") String id,@RequestParam("status") String status) {
		System.out.println("--------------------------");
		userService.changeUserStatus(Integer.parseInt(id),Integer.parseInt(status));
			return "redirect:listRegisteredUser.htm";
	}

}