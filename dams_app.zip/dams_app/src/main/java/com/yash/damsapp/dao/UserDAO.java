package com.yash.damsapp.dao;

import java.util.List;

import com.yash.damsapp.domain.User;

/**
 * This interface perform operation related with User.
 * @author shyam.patidar
 *
 */
public interface UserDAO {
	/**
	 * This method will save the User Object into database.Return 1 if data inserted into DB.
	 * @param user
	 * @return int
	 *
	 */
	public int insert(User user);

	public List<User> list();

	public int changeStatus(int id,int status);
	


	
}
