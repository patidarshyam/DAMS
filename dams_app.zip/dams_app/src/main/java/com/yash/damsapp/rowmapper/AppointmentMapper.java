package com.yash.damsapp.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.damsapp.domain.Appointment;


public class AppointmentMapper implements RowMapper<Appointment> {

	public Appointment mapRow(ResultSet resultSet, int i) throws SQLException {
		Appointment appointment=new Appointment();
		appointment.setId(resultSet.getInt("id"));
		appointment.setDate_created(resultSet.getDate("date_created"));
		appointment.setStart_time(resultSet.getTime("start_time"));
		appointment.setEnd_time(resultSet.getTime("end_time"));
		appointment.setEnd_time_expected(resultSet.getTime("end_time_expected"));
		appointment.setCancel(resultSet.getInt("cancelled"));
		appointment.setCancel_reason(resultSet.getString("cancel_reason"));
		appointment.setDiscount(resultSet.getInt("discount"));
		appointment.setFee(resultSet.getInt("fee"));
		appointment.setUserid(resultSet.getInt("userId"));
		appointment.setSlot(resultSet.getInt("slot"));
		appointment.setStatus(resultSet.getInt("status"));
		
		return appointment;
	}
	
}
