package com.yash.damsapp.command;

import javax.validation.constraints.Size;

public class BookAppointmentCommand {
	
	private int userId;
	private String date_created;
	private String start_time;

	
	public String getDate_created() {
		return date_created;
	}

	public void setDate_created(String date_created) {
		this.date_created = date_created;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	
	
	
}
