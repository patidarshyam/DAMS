package com.yash.damsapp.domain;
/**
 * This class will act as data traveler for user and act as a model.
 * make sure that there is no validation in this class.
 * @author shyam.patidar
 *
 */
public class User {
	public User() {
		this.role=2;
		this.status=1;
	}
	
	public User(String loginname, String password) {
		this.loginname=loginname;
		this.password=password;
	}
	/**
	 * This is the unique id of user
	 */
	private int id;
	/**
	 * firstname of the user
	 */
	private String first_name;
	/**
	 * lastname of the user
	 */
	private String last_name;
	/**
	 * email of the user
	 */
	private String email;
	/**
	 * contact number of the user
	 */
	private String contact;
	/**
	 * address of the user
	 */
	private String address;
	/**
	 * loginname of user
	 */
	private String loginname;
	/**
	 * password of user
	 */
	private String password;
	/**
	 * This is the role of user
	 * 1:Doctor,2:Patient
	 */
	private int role;
	/**
	 * This is the status of user
	 * 1:Active,2:Bolcked
	 */
	private int status;
	
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
