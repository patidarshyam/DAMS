package com.yash.damsapp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.yash.damsapp.command.BookAppointmentCommand;
import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.AppointmentService;

/**
 * This controller will perform Appointment related controlling.
 * 
 * @author shyam.patidar
 *
 */
@Controller
@RequestMapping("/appointment")
@SessionAttributes("userinsession")
public class AppointmentController {
	@Autowired
	private AppointmentService appointmentService;
	
	@RequestMapping(value = "/bookAppointment.htm", method = RequestMethod.GET)
	public String showAddAppointmentPage(HttpSession session,Model model) {
		User user = (User) session.getAttribute("userinsession");
		if (user.getLoginname() == null)
			return "userLogin";
		else
			return "bookAppointment";
	}
	@RequestMapping(value = "/processAppointment.htm", method = RequestMethod.POST)
	public String processAddAppointment(@ModelAttribute("command") BookAppointmentCommand bookAppointmentCommand,HttpSession session){
		User user = (User) session.getAttribute("userinsession");
		bookAppointmentCommand.setUserId(user.getId());
		appointmentService.addAppointment(bookAppointmentCommand);
		return "userDashboard";
	}
	@RequestMapping(value = "/listAppointment.htm", method = RequestMethod.GET)
	public String showAppointmentPage(HttpSession session,Model model) {
		User user = (User) session.getAttribute("userinsession");
		if (user.getLoginname() == null)
			return "userLogin";
		else {
			List<Appointment> listAppointment = appointmentService.listAppointment(user.getId());
			model.addAttribute("listAppointment", listAppointment);
			return "listAppointment";
		}
	}
	
	@RequestMapping(value = "/changeAppointmentStatus.htm", method = RequestMethod.GET)
	public String changeAppointmentStatus(@RequestParam("id") int id) {
		int result=appointmentService.changeAppointmentStatus(id);
		return "redirect:listAppointment.htm";
	}
	
	@RequestMapping(value = "/cancelAppointment.htm", method = RequestMethod.POST)
	public String cancelAppointment(@RequestParam("cancel_reason")String message,@RequestParam("id") int id){
		appointmentService.cancelAppointment(id,message);
		return "redirect:listAppointment.htm";
	}
}

