package com.yash.damsapp.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Service;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.rowmapper.UserMapper;
import com.yash.damsapp.service.UserService;
/**
 * This class is the implementation of userService interface
 * @author shyam.patidar
 *
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired
	private UserDAO userDAO;
	/**
	 * This method register the user.
	 */
	public int userRegistration(User user) {
		return userDAO.insert(user);
	}
	public User authenticateUser(User user) {
		String sql="SELECT * FROM users WHERE loginname=? AND password=?";
		Object[] params=new Object[]{
				user.getLoginname(),
				user.getPassword()
			};
		try{
			return jdbcTemplate.queryForObject(sql,params,new UserMapper());
		}catch (Exception e) {
			return null;
		}
	}
	public List<User> listRegisteredUser() {
		return userDAO.list();
	}
	public int changeUserStatus(int id,int status) {
		
		return userDAO.changeStatus(id,status);
	}
}
