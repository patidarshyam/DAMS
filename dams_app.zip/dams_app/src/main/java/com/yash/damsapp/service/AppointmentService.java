package com.yash.damsapp.service;

import java.util.List;

import com.yash.damsapp.command.BookAppointmentCommand;
import com.yash.damsapp.domain.Appointment;
/**
 * This interface provides the services related to Appointment.
 * @author shyam.patidar
 *
 */
public interface AppointmentService {
	
	public int addAppointment(BookAppointmentCommand bookAppointmentCommand);
	
	public List<Appointment> listAppointment(Integer userId);

	public int changeAppointmentStatus(int id);

	public int cancelAppointment(int id, String message);

}
