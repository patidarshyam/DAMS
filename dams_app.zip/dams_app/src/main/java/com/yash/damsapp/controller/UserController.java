package com.yash.damsapp.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
import com.yash.damsapp.command.UserLoginCommand;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;

/**
 * This controller will perform user related controlling.
 * 
 * @author shyam.patidar
 *
 */
@Controller
@RequestMapping("/user")
@SessionAttributes("userinsession")
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/home.htm", method = RequestMethod.GET)
	public String showHomePage() {
		return "home";
	}

	@RequestMapping(value = "/userRegistration.htm", method = RequestMethod.GET)
	public String showUserRegistration() {
		return "userRegistration";
	}

	@RequestMapping(value = "/processRegistration.htm", method = RequestMethod.POST)
	public String processUserRegistration(@ModelAttribute("user") User user, Model model) {
		int result = userService.userRegistration(user);
		if (result == 1) {
			model.addAttribute("success", "Registration Complete! Please Login");
			return "userLogin";
		} else {
			model.addAttribute("err", "Registration Failed!");
			return "userRegistration";
		}
	}

	@RequestMapping(value = "/userLogin.htm", method = RequestMethod.GET)
	public String showUserLoginForm(@ModelAttribute("command") UserLoginCommand userLoginCommand) {
		return "userLogin";
	}

	@RequestMapping(value = "/processLogin.htm", method = RequestMethod.POST)
	public String processUserLogin(Model model,@Valid @ModelAttribute("command") UserLoginCommand userLoginCommand,BindingResult result) {
		if(result.hasErrors()){
			return "userLogin";
		}
		User user = new User(userLoginCommand.getLoginname(), userLoginCommand.getPassword());
		user = userService.authenticateUser(user);
		if (user == null) {
			model.addAttribute("err", "Login Failed!");
			return "userLogin";
		}else if(user.getRole()==2){
			model.addAttribute("success", "Login success! Welcome "+user.getFirst_name()+" !!!!");
			model.addAttribute("userinsession", user);
			return "userDashboard";
		}else{
			model.addAttribute("success", "Login success! Welcome Admin!!!!");
			model.addAttribute("userinsession", user);
			return "adminDashboard";
		}
	}

	@RequestMapping(value = "/userDashboard.htm", method = RequestMethod.GET)
	public String showUserDashboard() {
		return "userDashboard";
	}
	@RequestMapping(value = "/adminDashboard.htm", method = RequestMethod.GET)
	public String showAdminDashboard() {
		return "adminDashboard";
	}
	@RequestMapping(value = "/processLogout.htm", method = RequestMethod.GET)
	public String processUserLogout(Model model, HttpSession session,@ModelAttribute("command") UserLoginCommand userLoginCommand) {
		model.addAttribute("success", "Successfully Logged out!");
		model.addAttribute("userinsession", new User());
		session.invalidate();

		return "userLogin";
	}

}