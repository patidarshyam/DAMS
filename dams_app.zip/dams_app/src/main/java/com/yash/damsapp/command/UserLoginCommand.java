package com.yash.damsapp.command;

import javax.validation.constraints.Size;

public class UserLoginCommand {
	@Size(min=1,max=15,message="LoginName should be between 1 to 15 characters.")
	private String loginname;
	@Size(min=6,max=15,message="Password should be between 6 to 15 characters.")
	private String password;
	
	public String getLoginname() {
		return loginname;
	}
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
