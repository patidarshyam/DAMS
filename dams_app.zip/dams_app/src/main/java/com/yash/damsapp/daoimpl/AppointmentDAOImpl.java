package com.yash.damsapp.daoimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.AppointmentDAO;
import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.rowmapper.AppointmentMapper;
/**
 * This is the implementation class of AppointmentDAO.
 * @author shyam.patidar
 *
 */
@Repository
public class AppointmentDAOImpl implements AppointmentDAO {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	/**
	 * this method inserting the appointment into database using jdbc template.
	 */
	public int insert(Appointment appointment) {
		int result=0;
		String sql="insert into appointments(userId,date_created,start_time,end_time_expected) values(?,?,?,?)";
		Object[] params=new Object[]{
			appointment.getUserid(),
			appointment.getDate_created(),
			appointment.getStart_time(),
			appointment.getEnd_time_expected()
		};
		return	jdbcTemplate.update(sql, params);	
	}
	public List<Appointment> select(Integer userId) {
		String sql = "SELECT * FROM appointments where userId=?";	
		Object[] params=new Object[]{
				userId
			};
		return jdbcTemplate.query(sql,params, new AppointmentMapper());
	}
	public int updateAppointmentStatus(int id) {
		return jdbcTemplate.update("UPDATE appointments SET status = ? where id = ?", 2, id);	
	}
	public int cancel(int id, String message) {
		String sql="UPDATE appointments SET cancelled=?,cancel_reason=?,status=? where id = ?";
		Object[] params=new Object[]{
				2,
				message,
				2,
				id
			};
		return jdbcTemplate.update(sql,params);	
	}

}
