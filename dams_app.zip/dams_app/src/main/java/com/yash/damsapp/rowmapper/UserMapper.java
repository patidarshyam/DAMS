package com.yash.damsapp.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.damsapp.domain.User;

public class UserMapper implements RowMapper<User> {

	public User mapRow(ResultSet resultSet, int i) throws SQLException {
		User user=new User();
		user.setId(resultSet.getInt("id"));
		user.setFirst_name(resultSet.getString("first_name"));
		user.setLast_name(resultSet.getString("last_name"));
		user.setContact(resultSet.getString("contact"));
		user.setEmail(resultSet.getString("email"));
		user.setAddress(resultSet.getString("address"));
		user.setLoginname(resultSet.getString("loginname"));
		user.setPassword(resultSet.getString("password"));
		user.setRole(resultSet.getInt("role"));
		user.setStatus(resultSet.getInt("status"));
		return user;
	}
	
	
	
}
