package com.yash.damsapp.serviceimpl;

import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.damsapp.command.BookAppointmentCommand;
import com.yash.damsapp.dao.AppointmentDAO;
import com.yash.damsapp.domain.Appointment;
import com.yash.damsapp.service.AppointmentService;
/**
 * This class is the implementation of AppointmentService interface
 * @author shyam.patidar
 *
 */
@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	private AppointmentDAO appointmentDAO;
	/**
	 * This method register the appointment.
	 * @param appointment
	 * @param userId
	 * @return int
	 * @author shyam.patidar
	 */
	public int addAppointment(BookAppointmentCommand bookAppointmentCommand) {
		Appointment appointment=new Appointment();
		try {
			System.out.println("=============================="+bookAppointmentCommand.getStart_time());
			
			Date temp_start_time = new SimpleDateFormat("HH:mm").parse(bookAppointmentCommand.getStart_time());
			Time start_time = new Time(temp_start_time.getTime());
			Date date_created = new SimpleDateFormat("yyyy-MM-dd").parse(bookAppointmentCommand.getDate_created());
			appointment.setUserid(bookAppointmentCommand.getUserId());
			appointment.setDate_created(date_created);
			appointment.setStart_time(start_time);
			//increasing time by 15 minutes
			Calendar cal=Calendar.getInstance();
			cal.setTime(temp_start_time);
			cal.add(Calendar.MINUTE, 15);
			Date newDate=cal.getTime();
			Time end_time_expected=new Time(newDate.getTime());
			
			appointment.setEnd_time_expected(end_time_expected);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return appointmentDAO.insert(appointment);
	}
	/**
	 * This method will return the List of appointments of individual user by userId
	 * @param userId
	 * @return List<Appointment>
	 *
	 */
	public List<Appointment> listAppointment(Integer userId) {
		return appointmentDAO.select(userId); 
	}
	public int changeAppointmentStatus(int id) {
		return appointmentDAO.updateAppointmentStatus(id);
	}
	public int cancelAppointment(int id, String message) {
		return appointmentDAO.cancel(id,message);	
	}

}
