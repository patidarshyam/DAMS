package com.yash.damsapp.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.rowmapper.UserMapper;
/**
 * This is the implementation class of UserDAO.
 * @author shyam.patidar
 *
 */
@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	/**
	 * this method inserting the user into database using jdbc template.
	 */
	public int insert(User user) {
		int result=0;
		String sql="insert into users(first_name,last_name,contact,email,address,loginname,password) values(?,?,?,?,?,?,?)";
		Object[] params=new Object[]{
			user.getFirst_name(),
			user.getLast_name(),
			user.getContact(),
			user.getEmail(),
			user.getAddress(),
			user.getLoginname(),
			user.getPassword()
		};
		try{
			result=jdbcTemplate.update(sql, params);
		}catch (Exception ex) {
			System.out.println("---"+ex.getMessage());
		}
		return result;
	}
	public List<User> list() {
		String sql = "SELECT * FROM users where role=2";	
		return jdbcTemplate.query(sql, new UserMapper());
	}
	public int changeStatus(int id,int status) {
		int changedStatus;
		if(status==1)
			changedStatus=2;
		else
			changedStatus=1;
		return jdbcTemplate.update("UPDATE users SET status = ? where id = ?", changedStatus, id);		
	}
	
}
